# IELTS Writing Check

Flask app that scores IELTS essays with the Claude API.

## Run locally
```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env            # then paste your ANTHROPIC_API_KEY
python app.py                   # open http://127.0.0.1:5000
```

## Deploy
```bash
gunicorn -w 2 -b 0.0.0.0:8000 app:app
```
- Put it behind Nginx with HTTPS.
- Behind a proxy, wrap the app with `werkzeug.middleware.proxy_fix.ProxyFix` so rate limits see real client IPs.
- With more than one worker, set the limiter `storage_uri` to Redis.
