"use strict";

const form = document.getElementById("form");
const essayEl = document.getElementById("essay");
const questionEl = document.getElementById("question");
const countEl = document.getElementById("count");
const submitBtn = document.getElementById("submit");
const errorEl = document.getElementById("error");
const resultEl = document.getElementById("result");

/** Create an element with optional class and text (textContent keeps output XSS-safe). */
function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function countWords(text) {
  const words = text.trim().match(/\S+/g);
  return words ? words.length : 0;
}

essayEl.addEventListener("input", () => {
  const n = countWords(essayEl.value);
  countEl.textContent = `${n} ${n === 1 ? "word" : "words"}`;
});

function showError(message) {
  errorEl.textContent = message;
  errorEl.hidden = !message;
}

function renderResult(data) {
  resultEl.replaceChildren();

  const band = el("div", "band");
  band.append(el("span", "band-num", data.overall_band.toFixed(1)), el("span", "band-label", "Estimated overall band"));
  resultEl.append(band);

  resultEl.append(el("h2", "", "Scores by criterion"));
  for (const c of data.criteria) {
    const box = el("div", "crit");
    const head = el("div", "crit-head");
    head.append(el("span", "", c.name), el("span", "", c.band.toFixed(1)));
    const meter = el("div", "meter");
    const fill = el("span");
    fill.style.width = `${(c.band / 9) * 100}%`;
    meter.append(fill);
    box.append(head, meter, el("p", "", c.comment));
    resultEl.append(box);
  }

  if (data.corrections.length) {
    resultEl.append(el("h2", "", "Fix these first"));
    for (const fix of data.corrections) {
      const item = el("div", "fix");
      const line = el("div");
      line.append(el("del", "", fix.original), " ", el("ins", "", fix.improved));
      item.append(line, el("p", "", fix.reason));
      resultEl.append(item);
    }
  }

  if (data.model_essay) {
    resultEl.append(el("h2", "", "Model answer"), el("p", "model", data.model_essay));
  }
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  showError("");

  submitBtn.disabled = true;
  submitBtn.textContent = "Checking...";
  resultEl.replaceChildren(el("p", "loading", "Reading your essay. This takes about 15 seconds."));

  try {
    const response = await fetch("/api/feedback", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        task: form.elements.task.value,
        question: questionEl.value,
        essay: essayEl.value,
      }),
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Something went wrong.");
    renderResult(data);
  } catch (err) {
    resultEl.replaceChildren(el("p", "empty", "Your feedback will appear here after you check an essay."));
    showError(err.message || "Network error. Check your connection and try again.");
  } finally {
    submitBtn.disabled = false;
    submitBtn.textContent = "Check my essay";
  }
});
